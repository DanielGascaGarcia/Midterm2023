"""
This is a stub for the comp16321 midterm.
Do not edit or delete any lines given in this file that are marked with a "(s)".
(you can move them to different lines as long as you do not change the overall structure)

Place your code below the comments marked "#Your code here".

Each method is documented to explain what work is to be placed within it.
"""

def read_results():#(s)
    # Your code here

    return (results_string)#(s)

def race_result(results_string):#(s)
    # Your code here

    return (race_result_string)#(s)

def race_result(results_string):#(s)
    # Your code here

    return (class_table_string)#(s)

def race_result(results_string):#(s)
    # Your code here

    return (class_table_discard_string)#(s)

def race_result(results_string):#(s)
    # Your code here

    return (medal_table_string)#(s)

def race_result(results_string):#(s)
    # Your code here

    return (disqualifications_string)#(s)


if __name__ == '__main__':
    # You can place any ad-hoc testing here
    # i.e mazes = read_mazes()
    # i.e print(mazes)
    pass
