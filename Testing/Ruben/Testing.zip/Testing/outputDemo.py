"""
Output the input.txt file as a list of strings
Note, just a portion of the file
"""
print("----- Task 01 -----")
results_string = ["0902-0701-0302-0403-08xx-0605-1006-0207-0508-0909-0910","0201-0701-0602-0503-0104-0905-0306-0807-0408-0209-0210","0402-0801-0902-1003-0604-0305-0406-0107-0208-0509-0510","0401-0601-1002-0703-0104-0405-0806-0307-0208-0909-0910","0101-1001-0802-0403-0704-0105-0606-0307-0908-0209-0210"]
print(results_string)

"""
Output the results of an individual classes race
The Class and Race to be outputted will be determined by the auto marker
Sample Output Result From Class 04 Race 03
"""
print("\n----- Task 02 -----")
race_result_string = "0601-0902-1003-0304-0505-0106-0707-0808-0409-0210"
print(race_result_string)

"""
Output the overall results for Class 6
"""
print("\n----- Task 03 -----")
class_table = "05-01-25, 03-02-36, 06-03-41, 08-04-43, 04-05-44, 09-06-45, 07-07-48, 10-08-50, 01-09-53, 02-10-58"
print(class_table)

"""
Output the updated overall results for Class 6 to exclude the 2 discarded results
"""
print("\n----- Task 04 -----")
class_table_discard = "05-01-21, 03-02-27, 06-03-33, 04-04-34, 08-05-36, 09-06-37, 07-07-38, 10-08-39, 02-09-47, 01-10-47"
print(class_table_discard)

"""
Output overall country medal table in order of medals
"""
print("\n----- Task 05 -----")
medal_table = "06-01-03-02-11, 03-01-03-00-09, 05-02-01-00-08, 09-02-00-01-07, 08-01-01-02-07, 07-02-00-00-06, 01-00-01-01-03, 10-00-00-02-02, 04-00-00-01-01, 02-00-00-00-00"
print(medal_table)

"""
Output country and class with the most race disqualifications
"""
print("\n----- Task 06 -----")
disqualifications = "1002-0602"
print(disqualifications)
